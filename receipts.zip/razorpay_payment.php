<?php
session_start();

// Include Razorpay SDK
require 'vendor/autoload.php';
use Razorpay\Api\Api;

// Razorpay API Keys
$api_key = 'rzp_live_SMuGxiXppBaM4C'; // Replace with your Razorpay API Key
$api_secret = 'LARG46LmwVkMHA2TElcc8fN6'; // Replace with your Razorpay API Secret

$api = new Api($api_key, $api_secret);

// Check if student_id is set in session
if (isset($_SESSION['id_no'])) {
    $student_id = $_SESSION['id_no'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "sfps_db");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to verify student_id in student_ef_list and id in student table
    $verify_query = "SELECT s.id, sef.student_id, sef.ef_no
                     FROM student_ef_list sef
                     JOIN student s ON sef.student_id = s.id
                     WHERE s.id_no = '$student_id'";

    $verify_result = $conn->query($verify_query);

    // Check if the student ID is found and matches
    if ($verify_result && $verify_result->num_rows > 0) {
        $student_data = $verify_result->fetch_assoc();
        $student_id = $student_data['id']; // Student ID from student table
        $ef_no = $student_data['ef_no']; // EF No from student_ef_list table

        // Fetch total fee for the student
        $fee_query = "SELECT sef.total_fee, s.name, s.email, s.contact 
                      FROM student_ef_list sef 
                      JOIN student s ON sef.student_id = s.id 
                      WHERE s.id = '$student_id'";
        $fee_result = $conn->query($fee_query);

        if ($fee_result && $fee_result->num_rows > 0) {
            $fee = $fee_result->fetch_assoc();
            $amount = $fee['total_fee'] * 100; // Razorpay expects amount in paise
            $student_name = $fee['name'];
            $student_email = $fee['email'];
            $student_contact = $fee['contact'];

            // Razorpay order creation
            $orderData = [
                'receipt' => 'rcptid_' . uniqid(),
                'amount' => $amount, // Amount in paise
                'currency' => 'INR',
                'payment_capture' => 1 // Auto-capture payment
            ];

            $order = $api->order->create($orderData);

            // Ensure remarks is not null (default to "Fee Payment" if not set)
            $remarks = "Fee Payment"; // You can change this to any other value
            if (empty($remarks)) {
                $remarks = "Fee Payment"; // Default value
            }
	     $amount_in_inr = $amount / 100;
            // Store payment details in the database
            $stmt_insert = $conn->prepare("INSERT INTO payments (ef_id, amount, remarks, date_created) 
                                           VALUES (?, ?, ?, NOW())");
            $stmt_insert->bind_param("iis", $ef_no, $amount_in_inr, $remarks);
            $stmt_insert->execute();

            if ($stmt_insert->affected_rows > 0) {
                // Payment details inserted successfully
            } else {
                echo "Error: " . $conn->error;
                exit;
            }
        } else {
            echo "Fee details not found.";
            exit;
        }

    } else {
        echo "Error: Student ID or EF Number not found in the database.";
        exit;
    }
} else {
    echo "User not logged in.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay with Razorpay</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>
    <button id="rzp-button">Pay Now</button>
    <script>
        const options = {
            "key": "<?php echo $api_key; ?>", // Razorpay API Key
            "amount": "<?php echo $amount; ?>", // Amount in paise
            "currency": "INR",
            "name": "<?php echo $student_name; ?>",
            "description": "Fee Payment",
            "image": "https://your-logo-url.com/logo.png", // Change to your logo
            "handler": function (response) {
                // Handle successful payment
                const payment_id = response.razorpay_payment_id;
                const amount_paid = "<?php echo $amount; ?>";
                const remarks = "<?php echo $remarks; ?>"; // Pass the remarks to the URL

                // After payment is completed, you can add any action or redirection here
                window.location.href = `payment_success.php?payment_id=${payment_id}&amount=${amount_paid}&remarks=${encodeURIComponent(remarks)}`;
            },
            "prefill": {
                "name": "<?php echo $student_name; ?>",
                "email": "<?php echo $student_email; ?>",
                "contact": "<?php echo $student_contact; ?>"
            },
            "theme": {
                "color": "#3399cc"
            }
        };
        const rzp = new Razorpay(options);
        document.getElementById('rzp-button').onclick = function (e) {
            rzp.open();
            e.preventDefault();
        };
    </script>
</body>
</html>
