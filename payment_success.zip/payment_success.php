<?php
session_start();

// Include Razorpay SDK and PHPMailer
require 'vendor/autoload.php';
use Razorpay\Api\Api;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// TCPDF Library
require_once('vendor/tecnickcom/tcpdf/tcpdf.php');

// Razorpay API Keys
$api_key = 'rzp_live_SMuGxiXppBaM4C'; // Replace with your Razorpay API Key
$api_secret = 'LARG46LmwVkMHA2TElcc8fN6'; // Replace with your Razorpay API Secret

$api = new Api($api_key, $api_secret);

// Directory to save receipts
$receipts_dir = __DIR__ . '/receipts/';
if (!is_dir($receipts_dir)) {
    mkdir($receipts_dir, 0777, true);
}

// Database connection
$conn = new mysqli("localhost", "root", "", "sfps_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure student ID is retrieved from session
$student_id = $_SESSION['id_no'];

// Query to verify student ID in student_ef_list and student table
$verify_query = "SELECT sef.id AS sef_id, sef.total_fee, s.id AS student_id, s.name, s.email, s.contact
                 FROM student_ef_list sef
                 JOIN student s ON sef.student_id = s.id
                 WHERE s.id_no = '$student_id'";
$verify_result = $conn->query($verify_query);

if ($verify_result && $verify_result->num_rows > 0) {
    $student_data = $verify_result->fetch_assoc();
    $sef_id = $student_data['sef_id'];
    $total_fee = $student_data['total_fee'];
    $student_name = $student_data['name'];
    $student_email = $student_data['email'];
    $student_contact = $student_data['contact'];

    // Calculate balance fee
    $paid_query = "SELECT SUM(amount) AS total_paid FROM payments WHERE ef_id = $sef_id";
    $paid_result = $conn->query($paid_query);
    $total_paid = $paid_result->fetch_assoc()['total_paid'] ?? 0;
    $balance_fee = $total_fee - $total_paid;

    // Check for payment amount from GET or POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
        $amount_paid = (float)$_POST['amount'];
    } elseif (isset($_GET['amount'])) {
        $amount_paid = (float)$_GET['amount'];
    } else {
        echo "Payment amount not specified.";
        exit;
    }

    // Validate payment amount
    if ($amount_paid <= 0 || $amount_paid > $balance_fee) {
        echo "Invalid payment amount. Please ensure it is greater than zero and does not exceed the balance fee.";
        exit;
    }

    // Razorpay order creation
    $orderData = [
        'receipt' => 'rcptid_' . uniqid(),
        'amount' => $amount_paid * 100, // Convert to paise
        'currency' => 'INR',
        'payment_capture' => 1
    ];
    $order = $api->order->create($orderData);

    // Store payment details in the database
    $remarks = "Installment Payment";
    $stmt_insert = $conn->prepare("INSERT INTO payments (ef_id, amount, remarks, date_created) VALUES (?, ?, ?, NOW())");
    $stmt_insert->bind_param("ids", $sef_id, $amount_paid, $remarks);
    $stmt_insert->execute();

    if ($stmt_insert->affected_rows > 0) {
        echo "Payment recorded successfully.";

        // Generate the receipt content (HTML format)
        $receipt_html = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
                    .receipt-container { margin: auto; padding: 20px; border: 1px solid #ccc; background-color: white; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1); }
                    h1 { text-align: center; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    table, th, td { border: 1px solid #ddd; }
                    th, td { padding: 10px; text-align: left; }
                </style>
            </head>
            <body>
                <div class='receipt-container'>
                    <h1>Payment Receipt</h1>
                    <p><strong>Payment ID:</strong> {$order['id']}</p>
                    <p><strong>Amount Paid:</strong> ₹" . number_format($amount_paid, 2) . "</p>
                    <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
                    <table>
                        <tr><th>Total Fee</th><td>₹" . number_format($total_fee, 2) . "</td></tr>
                        <tr><th>Total Paid</th><td>₹" . number_format($total_paid + $amount_paid, 2) . "</td></tr>
                        <tr><th>Balance Fee</th><td>₹" . number_format($balance_fee - $amount_paid, 2) . "</td></tr>
                    </table>
                </div>
            </body>
            </html>
        ";

        // Generate the PDF receipt
        $pdf = new TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 12);
        $pdf->writeHTML($receipt_html);
        $pdf_file = $receipts_dir . 'pay_' . $order['id'] . '_receipt.pdf';
        $pdf->Output($pdf_file, 'F'); // Save the PDF file

        // Send the receipt via email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = '0422msrinivasa@gmail.com';
            $mail->Password = 'bell ptxc uebm qgdx';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->setFrom('0422msrinivasa@gmail.com', 'School Fee Payment');
            $mail->addAddress($student_email, $student_name);
            $mail->addAttachment($pdf_file);
            $mail->isHTML(true);
            $mail->Subject = 'Payment Receipt';
            $mail->Body = $receipt_html;
            $mail->send();
            echo 'Receipt sent to email.';
        } catch (Exception $e) {
            echo "Email sending failed: {$mail->ErrorInfo}";
        }
    } else {
        echo "Error recording payment.";
    }
} else {
    echo "Student verification failed.";
}
?>                        