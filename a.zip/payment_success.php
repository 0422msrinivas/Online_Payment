<?php
session_start();

// Include Razorpay SDK and PHPMailer
require 'vendor/autoload.php';
use Razorpay\Api\Api;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// TCPDF Library
require_once('vendor/tecnickcom/tcpdf/tcpdf.php');

// Razorpay API Keys
$api_key = 'rzp_live_SMuGxiXppBaM4C'; // Replace with your Razorpay API Key
$api_secret = 'LARG46LmwVkMHA2TElcc8fN6'; // Replace with your Razorpay API Secret

$api = new Api($api_key, $api_secret);

// Directory to save receipts
$receipts_dir = __DIR__ . '/receipts/';

// Ensure the receipts directory exists, and create it if it doesn't
if (!is_dir($receipts_dir)) {
    mkdir($receipts_dir, 0777, true);
}

// Database connection
$conn = new mysqli("localhost", "root", "", "sfps_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure student ID is retrieved from session
$student_id = $_SESSION['id_no'];

// Query to verify student ID in student_ef_list and student table
$verify_query = "SELECT sef.id AS sef_id, sef.student_id, sef.ef_no, s.id AS student_id
                 FROM student_ef_list sef
                 JOIN student s ON sef.student_id = s.id
                 WHERE s.id_no = '$student_id'";
$verify_result = $conn->query($verify_query);

if ($verify_result && $verify_result->num_rows > 0) {
    $student_data = $verify_result->fetch_assoc();
    $sef_id = $student_data['sef_id'];
    $student_id = $student_data['student_id'];
    $ef_no = $student_data['ef_no'];

    // Fetch total fee for the student
    $fee_query = "SELECT sef.total_fee, s.name, s.email, s.contact 
                  FROM student_ef_list sef 
                  JOIN student s ON sef.student_id = s.id 
                  WHERE s.id = '$student_id'";
    $fee_result = $conn->query($fee_query);

    if ($fee_result && $fee_result->num_rows > 0) {
        $fee = $fee_result->fetch_assoc();
        $amount = $fee['total_fee'] * 100; // Convert to paise for Razorpay
        $student_name = $fee['name'];
        $student_email = $fee['email'];
        $student_contact = $fee['contact'];

        // Razorpay order creation
        $orderData = [
            'receipt' => 'rcptid_' . uniqid(),
            'amount' => $amount,
            'currency' => 'INR',
            'payment_capture' => 1
        ];
        $order = $api->order->create($orderData);

        // Ensure remarks is not null
        $remarks = "Fee Payment";
        $amount_in_inr = $amount / 100;

        // Store payment details in the database
        $stmt_insert = $conn->prepare("INSERT INTO payments (ef_id, amount, remarks, date_created) 
                                       VALUES (?, ?, ?, NOW())");
        $stmt_insert->bind_param("iis", $sef_id, $amount_in_inr, $remarks);
        $stmt_insert->execute();

        if ($stmt_insert->affected_rows > 0) {
            echo "Payment initiated successfully.";
        } else {
            echo "Error storing payment details: " . $conn->error;
            exit;
        }

        // Payment success
        if (isset($_GET['payment_id']) && isset($_GET['amount'])) {
            $payment_id = $_GET['payment_id'];
            $amount = $_GET['amount'];
            echo "<h1>Payment Successful</h1>";
            echo "<p>Payment ID: $payment_id</p>";
            echo "<p>Amount Paid: ₹" . number_format($amount , 2) . "</p>";

            // Generate the receipt content (HTML format)
            $receipt_html = "
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            padding: 20px;
                            background-color: #f9f9f9;
                        }
                        .receipt-container {
                            width: 60%;
                            margin: auto;
                            padding: 10px;
                            border: 1px solid #ccc;
                            background-color: white;
                            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
                        }
                        h1 {
                            text-align: center;
                            color: #333;
                        }
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                        }
                        table, th, td {
                            border: 1px solid #ddd;
                        }
                        th, td {
                            padding: 10px;
                            text-align: left;
                        }
                        .btn-print {
                            display: block;
                            margin: 20px auto;
                            padding: 10px 20px;
                            background-color: #4CAF50;
                            color: white;
                            border: none;
                            cursor: pointer;
                            font-size: 16px;
                        }
                        .btn-print:hover {
                            background-color: #45a049;
                        }
                    </style>
                </head>
                <body>
                    <div class='receipt-container'>
                        <h1>Payment Receipt</h1>
                        <p><strong>Payment ID:</strong> $payment_id</p>
                        <p><strong>Amount:</strong> ₹" . number_format($amount_in_inr, 2) . "</p>
                        <p><strong>Payment Status:</strong> Successful</p>
                        <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
                        <table>
                            <tr>
                                <th>Amount Paid</th>
                                <td>₹" . number_format($amount_in_inr, 2) . "</td>
                            </tr>
                            <tr>
                                <th>Payment Status</th>
                                <td>Successful</td>
                            </tr>
                            <tr>
                                <th>Payment Date</th>
                                <td>" . date('Y-m-d H:i:s') . "</td>
                            </tr>
                        </table>
                    </div>
                </body>
                </html>
            ";

            // Generate the PDF receipt using TCPDF
            $pdf = new TCPDF();
            $pdf->AddPage();
            $pdf->SetFont('helvetica', '', 12);
            $pdf->writeHTML($receipt_html);

            // Path to save the PDF
            $pdf_file = $receipts_dir . 'pay_' . $payment_id . '_receipt.pdf';
            $pdf->Output($pdf_file, 'F'); // Save the PDF file

            // Send the receipt via email
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = '0422msrinivasa@gmail.com';  // SMTP username
                $mail->Password = 'bell ptxc uebm qgdx';        // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('0422msrinivasa@gmail.com', 'School Fee Payment');
                $mail->addAddress($student_email, $student_name);
                $mail->addAttachment($pdf_file); // Attach the generated PDF receipt

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Payment Receipt';
                $mail->Body = $receipt_html; // Include receipt details in the email body

                // Send the email
                $mail->send();
                echo 'Receipt has been sent to the student email.';
            } catch (Exception $e) {
                echo "Error sending email: {$mail->ErrorInfo}";
            }
        } else {
            echo "<h1>Error</h1>";
            echo "<p>Payment details not found.</p>";
        }
    } else {
        echo "Fee details not found.";
        exit;
    }
} else {
    echo "Student verification failed.";
    exit;
}
?>
