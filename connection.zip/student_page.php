<?php
session_start();

// Check if the student_id is set in the session
if (isset($_SESSION['id_no'])) {
    $student_id = $_SESSION['id_no'];  // Get the student_id from session
} else {
    echo "User not logged in.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Fee Details</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    :root {
    --primary-color: #4CAF50;        /* Main button and highlight color */
    --primary-hover: #45a049;        /* Button hover */
    --background-color: #f4f4f9;     /* Page background */
    --border-color: #ddd;            /* Table and card borders */
    --text-color: #333;              /* General text color */
}

body {
    font-family: Arial, sans-serif;
    color: var(--text-color);
    background-color: var(--background-color);
}

.container {
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    width: 80%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.header {
    text-align: center;
}

.actions {
    text-align: center;
    margin-top: 20px;
}

table {
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid var(--border-color);
}

th, td {
    padding: 10px;
    text-align: left;
}

button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: var(--primary-hover);
}
</style>
<body style="background-color:rgb(62, 80, 81);">
    <div class="container mt-5">
        <div class="card shadow-lg">
            <div class="card-header bg-primary text-white text-center">
                <h3 class="mb-0">Student Fee Details</h3>
            </div>
            <div class="card-body">
                <h5 class="text-muted">User ID: <span class="badge bg-secondary"><?php echo $student_id; ?></span></h5>
                <hr>

                <?php
                $conn = new mysqli("localhost", "root", "", "sfps_db");
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch student info
                $student_query = "SELECT * FROM student WHERE id_no = '$student_id'";
                $student_result = $conn->query($student_query);

                if ($student_result && $student_result->num_rows > 0) {
                    $student = $student_result->fetch_assoc();
                    echo "<p><strong>Name:</strong> {$student['name']}</p>";
                    echo "<p><strong>Contact:</strong> {$student['contact']}</p>";
                    echo "<p><strong>Email:</strong> {$student['email']}</p>";
                    echo "<p><strong>Address:</strong> {$student['address']}</p>";
                    echo "<p><strong>Admission Type:</strong> {$student['admission_type']}</p>";
                } else {
                    echo "<div class='alert alert-warning'>Student not found.</div>";
                }

                // Fee details
                $fee_query = "SELECT sef.total_fee, c.course 
                              FROM student_ef_list sef
                              JOIN student s ON sef.student_id = s.id
                              JOIN courses c ON sef.course_id = c.id
                              WHERE s.id = (SELECT id FROM student WHERE id_no = '$student_id')";
                $fee_result = $conn->query($fee_query);
                $total_fee = 0;

                if ($fee_result && $fee_result->num_rows > 0) {
                    while ($fee = $fee_result->fetch_assoc()) {
                        echo "<p><strong>Course:</strong> {$fee['course']}</p>";
                        $total_fee = $fee['total_fee'];
                        echo "<p><strong>Total Fee:</strong> ₹{$fee['total_fee']}</p>";
                    }
                } else {
                    echo "<div class='alert alert-warning'>Fee details not found.</div>";
                }

                // Paid amount
                $payment_query = "SELECT SUM(p.amount) AS total_paid 
                                  FROM payments p
                                  JOIN student_ef_list sef ON sef.id = p.ef_id
                                  JOIN student s ON s.id = sef.student_id
                                  WHERE s.id_no = '$student_id'";
                $payment_result = $conn->query($payment_query);
                $total_paid = 0;

                if ($payment_result && $payment_result->num_rows > 0) {
                    $payment = $payment_result->fetch_assoc();
                    $total_paid = $payment['total_paid'];
                }

                $balance_fee = $total_fee - $total_paid;

                echo "<p><strong>Total Paid:</strong> ₹{$total_paid}</p>";
                echo "<p><strong>Balance Fee:</strong> ₹{$balance_fee}</p>";

                // Payment history
                $payment_history_query = "SELECT p.date_created, p.amount, p.remarks  
                                          FROM student s 
                                          JOIN student_ef_list sef ON s.id = sef.student_id 
                                          JOIN payments p ON sef.id = p.ef_id 
                                          WHERE s.id_no = '$student_id'";

                $payment_history_result = $conn->query($payment_history_query);

                if ($payment_history_result && $payment_history_result->num_rows > 0) {
                    echo "<h5 class='mt-4'>Payment History</h5>";
                    echo "<div class='table-responsive'>";
                    echo "<table class='table table-striped table-bordered'>";
                    echo "<thead class='table-dark'><tr><th>Date</th><th>Amount (₹)</th><th>Remarks</th></tr></thead><tbody>";
                    while ($payment = $payment_history_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$payment['date_created']}</td>";
                        echo "<td>{$payment['amount']}</td>";
                        echo "<td>{$payment['remarks']}</td>";
                        echo "</tr>";
                    }
                    echo "</tbody></table></div>";
                } else {
                    echo "<div class='alert alert-info'>No payment history found.</div>";
                }

                $conn->close();
                ?>

                <div class="text-center mt-4">
                    <a href="razorpay_payment.php?id_no=<?php echo $student_id; ?>" class="btn btn-success btn-lg">Pay Now</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>