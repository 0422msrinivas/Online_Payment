<?php
session_start();

// Check if the student_id is set in the session
if (isset($_SESSION['id_no'])) {
    $student_id = $_SESSION['id_no'];  // Get the student_id from session
} else {
    // If not set, handle accordingly (e.g., show an error or redirect)
    echo "User not logged in.";
    exit;  // Terminate further script execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Fee Details</title>
    <style>
        /* Add your CSS here */
        .container {
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f9;
            border-radius: 8px;
            width: 80%;
            margin: auto;
        }

        .header {
            text-align: center;
        }

        .actions {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        button {
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Student Fee Details</h2>
            <p><strong>User ID:</strong> <?php echo $student_id; ?></p> <!-- Display user ID here -->
        </div>

        <?php
        // Database connection
        $conn = new mysqli("localhost", "root", "", "sfps_db");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch student details based on id_no from student table
        $student_query = "SELECT * FROM student WHERE id_no = '$student_id'";
        $student_result = $conn->query($student_query);

        if ($student_result && $student_result->num_rows > 0) {
            $student = $student_result->fetch_assoc();
            echo "<p><strong>Name:</strong> {$student['name']}</p>";
            echo "<p><strong>Contact:</strong> {$student['contact']}</p>";
            echo "<p><strong>Email:</strong> {$student['email']}</p>";
            echo "<p><strong>Address:</strong> {$student['address']}</p>";
            echo "<p><strong>Admission Type:</strong> {$student['admission_type']}</p>";
        } else {
            echo "<p>Student not found.</p>";
        }

        // Fetch total fee from student_ef_list by matching student.id with student_ef_list.student_id
        $fee_query = "SELECT sef.total_fee, c.course 
                      FROM student_ef_list sef
                      JOIN student s ON sef.student_id = s.id
                      JOIN courses c ON sef.course_id = c.id
                      WHERE s.id = (SELECT id FROM student WHERE id_no = '$student_id')";
        $fee_result = $conn->query($fee_query);
        $total_fee = 0;  // Variable to store the total fee

        if ($fee_result && $fee_result->num_rows > 0) {
            while ($fee = $fee_result->fetch_assoc()) {
                echo "<p><strong>Course:</strong> {$fee['course']}</p>";
                $total_fee = $fee['total_fee'];  // Get the total fee
                echo "<p><strong>Total Fee:</strong> {$fee['total_fee']}</p>";
            }
        } else {
            echo "<p>Fee details not found.</p>";
        }

        // Fetch total paid amount from payments table
        $payment_query = "SELECT SUM(p.amount) AS total_paid 
                          FROM payments p
                          JOIN student_ef_list sef ON sef.id = p.ef_id
                          JOIN student s ON s.id = sef.student_id
                          WHERE s.id_no = '$student_id'";

        $payment_result = $conn->query($payment_query);
        $total_paid = 0;  // Variable to store the total paid amount

        if ($payment_result && $payment_result->num_rows > 0) {
            $payment = $payment_result->fetch_assoc();
            $total_paid = $payment['total_paid'];  // Get the total paid amount
        }

        // Calculate balance fee
        $balance_fee = $total_fee - $total_paid;

        // Display balance fee
        echo "<p><strong>Balance Fee:</strong> {$balance_fee}</p>";

        // Fetch payment history using the student_id (from session)
        $payment_history_query = "SELECT p.date_created, p.amount, p.remarks  
                                  FROM student s 
                                  JOIN student_ef_list sef ON s.id = sef.student_id 
                                  JOIN payments p ON sef.id = p.ef_id 
                                  WHERE s.id_no = '$student_id'";

        $payment_history_result = $conn->query($payment_history_query);

        if ($payment_history_result && $payment_history_result->num_rows > 0) {
            echo "<h3>Payment History</h3>";
            echo "<table>";
            echo "<tr><th>Date</th><th>Amount</th><th>Remarks</th></tr>";
            while ($payment = $payment_history_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$payment['date_created']}</td>";
                echo "<td>{$payment['amount']}</td>";
                echo "<td>{$payment['remarks']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No payment history found.</p>";
        }

        $conn->close();
        ?>

        <div class="actions">
           <button onclick="window.location.href='razorpay_payment.php?id_no=<?php echo $student_id; ?>'">Pay Fee</button>
        </div>
    </div>
</body>
</html>
